    <div class="footer">
        <div class="wrapper">
            <p class="text-center">
                2022 All rights reserved to Xrestaurant, Developed by Ariel_Corte_
            </p>
        </div>
    </div>
</body>
</html>