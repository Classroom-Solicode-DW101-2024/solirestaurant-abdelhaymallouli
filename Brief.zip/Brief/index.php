<?php

require 'config.php';

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Plats par Type de Cuisine</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .cuisine-section {
            margin-bottom: 40px;
            margin-left: 40px;
        }

        .cuisine-title {
            font-size: 29px;
            margin-bottom: 20px;
            border-bottom: 2px solid #ccc;
            padding-bottom: 7px;
            text-align: center;
        }

        .card {
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.1);
            display: inline-block;
            margin: 10px;
            width: 250px;
            vertical-align: top;
            overflow: hidden;
            cursor: pointer;
        }

        .card:hover {
            transform: scale(0.99);
        }

        .card img {
            width: 250px;
            height: 200px;
            object-fit: cover;
            border-bottom: 1px solid #ddd;
        }

        .card-content {
            padding: 10px;
        }

        .card-content h3 {
            margin: 0 0 10px;
            font-size: 18px;
        }

        .card-content p {
            margin: 5px 0;
            color: #555;
        }
    </style>
</head>

<body>
    <?php foreach ($platsByCuisine as $typeCuisine => $plats): ?>
        <div class="cuisine-section">
            <h2 class="cuisine-title"><?= htmlspecialchars($typeCuisine) ?></h2>
            <?php foreach ($plats as $plat): ?>
                <div class="card">
                    <img src="<?= isset($plat['image']) ? htmlspecialchars($plat['image']) : 'placeholder.jpg' ?>" 
                         alt="<?= htmlspecialchars($plat['nomPlat']) ?>">
                    <div class="card-content">
                        <h3><?= htmlspecialchars($plat['nomPlat']) ?></h3>
                        <p>Catégorie : <?= htmlspecialchars($plat['categoriePlat']) ?></p>
                        <p>Prix : <?= htmlspecialchars($plat['prix']) ?> DH</p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endforeach; ?>
</body>

</html>


